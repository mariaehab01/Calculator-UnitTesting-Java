package main;

public interface ICalculatorService {
    int sum(int a, int b);
    int divide(int a, int b);
}
